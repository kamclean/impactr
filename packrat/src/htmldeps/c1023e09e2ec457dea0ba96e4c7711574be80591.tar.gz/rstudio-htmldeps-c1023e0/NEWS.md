# htmldeps 0.1.1

* Added a CSS file to support the Bootswatch `darkly` theme in R Markdown

# htmldeps 0.1.0

* New package, adds the following HTML dependencies for **rmarkdown**: jQuery (v1.11.3), jQuery UI (v1.11.4), Twitter Bootstrap (v3.3.5), Tocify (v1.9.1), FontAwesome (v5.1.0), and Ionicons (v2.0.1) 
