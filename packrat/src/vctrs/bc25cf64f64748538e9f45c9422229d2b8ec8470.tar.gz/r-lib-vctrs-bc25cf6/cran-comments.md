
The valgrind errors are fixed.

This is a resubmission that fixes a broken link in the README.

## Test environments

* local macOS: release
* Travis Ubuntu: 3.2, 3.3, oldrel, release, devel
* win-builder: release, devel
* R-Hub: UBSAN, rchk, and valgrind builds


## R CMD check results

0 errors | 0 warnings | 0 notes


## Revdep checks

There are expected test failures in the tidyr and rray packages. We'll send updates for these packages shortly after release.
