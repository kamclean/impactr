
class_type <- function(x) {
  .Call(vctrs_class_type, x)
}
