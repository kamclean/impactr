library(testthat)
library(rscopus)

test_check("rscopus")
