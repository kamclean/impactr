library("testthat")
test_check("fauxpas")
