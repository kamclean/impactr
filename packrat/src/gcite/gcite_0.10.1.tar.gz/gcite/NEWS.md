# gcite 0.10.0

* Fixing the `gcite_username` fails with new Google HTML.

# gcite 0.9.3

* Corrected author data if patents, not articles.
* Changed examples to authors with fewer papers for speed of example.

# gcite 0.9.1

* Fixed errors with certain graphs on main page.

# gcite 0.8.1

* New version to CRAN.

* Fixed changes to the Google Scholar page.  

* Added a `NEWS.md` file to track changes to the package.
