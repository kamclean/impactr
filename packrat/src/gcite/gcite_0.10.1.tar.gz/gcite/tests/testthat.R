library(testthat)
library(gcite)

test_check("gcite")
