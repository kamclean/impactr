library(testthat)
library(urltools)

test_check("urltools")
