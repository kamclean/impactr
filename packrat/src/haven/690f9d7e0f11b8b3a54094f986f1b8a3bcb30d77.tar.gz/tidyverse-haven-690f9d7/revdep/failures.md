# bpnreg

<details>

* Version: 1.0.1
* Source code: https://github.com/cran/bpnreg
* URL: https://github.com/joliencremers/bpnreg
* BugReports: https://github.com/joliencremers/bpnreg/issues
* Date/Publication: 2019-11-05 13:20:02 UTC
* Number of recursive dependencies: 26

Run `revdep_details(,"bpnreg")` for more info

</details>

## In both

*   checking whether package ‘bpnreg’ can be installed ... ERROR
    ```
    Installation failed.
    See ‘/Users/hadley/Documents/tidyverse/haven/revdep/checks.noindex/bpnreg/new/bpnreg.Rcheck/00install.out’ for details.
    ```

## Installation

### Devel

```
* installing *source* package ‘bpnreg’ ...
** package ‘bpnreg’ successfully unpacked and MD5 sums checked
** using staged installation
** libs
clang++ -std=gnu++11 -I"/Library/Frameworks/R.framework/Resources/include" -DNDEBUG  -I"/Users/hadley/Documents/tidyverse/haven/revdep/library.noindex/haven/new/Rcpp/include" -I"/Users/hadley/Documents/tidyverse/haven/revdep/library.noindex/bpnreg/RcppArmadillo/include" -I"/Users/hadley/Documents/tidyverse/haven/revdep/library.noindex/haven/new/BH/include" -isysroot /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk -I/usr/local/include -fopenmp -fPIC  -Wall -g -O2  -c RcppExports.cpp -o RcppExports.o
clang: error: unsupported option '-fopenmp'
make: *** [RcppExports.o] Error 1
ERROR: compilation failed for package ‘bpnreg’
* removing ‘/Users/hadley/Documents/tidyverse/haven/revdep/checks.noindex/bpnreg/new/bpnreg.Rcheck/bpnreg’

```
### CRAN

```
* installing *source* package ‘bpnreg’ ...
** package ‘bpnreg’ successfully unpacked and MD5 sums checked
** using staged installation
** libs
clang++ -std=gnu++11 -I"/Library/Frameworks/R.framework/Resources/include" -DNDEBUG  -I"/Users/hadley/Documents/tidyverse/haven/revdep/library.noindex/haven/old/Rcpp/include" -I"/Users/hadley/Documents/tidyverse/haven/revdep/library.noindex/bpnreg/RcppArmadillo/include" -I"/Users/hadley/Documents/tidyverse/haven/revdep/library.noindex/haven/old/BH/include" -isysroot /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk -I/usr/local/include -fopenmp -fPIC  -Wall -g -O2  -c RcppExports.cpp -o RcppExports.o
clang: error: unsupported option '-fopenmp'
make: *** [RcppExports.o] Error 1
ERROR: compilation failed for package ‘bpnreg’
* removing ‘/Users/hadley/Documents/tidyverse/haven/revdep/checks.noindex/bpnreg/old/bpnreg.Rcheck/bpnreg’

```
