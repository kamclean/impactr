library(testthat)
library(triebeard)

test_check("triebeard")
