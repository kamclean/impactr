## Test environments

* local OS X install, R 3.6.1 patched
* ubuntu 14.04 (on travis-ci), R 3.6.1
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 0 notes

## Reverse dependencies

* There are no reverse dependencies.

---

This version fixes better checks if http requests will work before running examples that require http requests.

Thanks!
Scott Chamberlain
