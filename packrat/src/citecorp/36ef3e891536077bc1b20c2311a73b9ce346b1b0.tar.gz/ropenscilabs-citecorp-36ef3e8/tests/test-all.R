library("testthat")
test_check("citecorp")
