# concaveman 1.0

- initial release
- supports different input and output formats (matrix of coordinates, `SpatialPoints*`, `sf`)
