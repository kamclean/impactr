library(testthat)
library(concaveman)

test_check("concaveman")
