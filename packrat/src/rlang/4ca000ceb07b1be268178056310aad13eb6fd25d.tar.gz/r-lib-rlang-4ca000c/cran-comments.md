
This should fix rlang on r-devel.


## Test environments

* local OS X install: release
* travis-ci: 3.2, 3.3, 3.4, 3.5, release, and devel
* win-builder: devel and release
* rchk: unbuntu-rchk platform on R-hub


## R CMD check results

0 errors | 0 warnings | 0 notes


## Reverse dependencies

This is a trivial maintenance release so I haven't checked reverse dependencies.
