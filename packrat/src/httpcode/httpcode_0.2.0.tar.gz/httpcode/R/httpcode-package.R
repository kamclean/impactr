#' Explain the meaning of HTTP status codes
#'
#' @name httpcode-package
#' @aliases httpcode
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
