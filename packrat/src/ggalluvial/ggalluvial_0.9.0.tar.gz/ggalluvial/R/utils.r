# color and differentiation aesthetics
.color_diff_aesthetics <- c(
  "fill", "bg", "fg", "col", "colour", "color", "alpha",
  "lty", "linetype", "cex", "lwd", "size", "pch", "shape"
)
