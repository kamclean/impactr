# estimatr

Version: 0.14

## In both

*   checking package dependencies ... NOTE
    ```
    Package which this enhances but not available for checking: ‘texreg’
    ```

*   checking Rd cross-references ... NOTE
    ```
    Package unavailable to check Rd xrefs: ‘texreg’
    ```

# keras

Version: 2.2.4

## In both

*   checking installed package size ... NOTE
    ```
      installed size is  5.9Mb
      sub-directories of 1Mb or more:
        doc   4.4Mb
    ```

# parsnip

Version: 0.0.1

## In both

*   checking tests ...
    ```
     ERROR
    Running the tests in ‘tests/testthat.R’ failed.
    Last 13 lines of output:
         2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 2L, 
         2L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 
         3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 
         3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L), .Label = c("setosa", "versicolor", "virginica"
         ), class = "factor", contrasts = "contr.dummy"), TRUE)
      18: get(ctr, mode = "function", envir = parent.frame())
      
      ══ testthat results  ═══════════════════════════════════════════════════════════
      OK: 678 SKIPPED: 21 FAILED: 3
      1. Error: submodel prediction (@test_boost_tree_C50.R#113) 
      2. Error: kknn prediction (@test_nearest_neighbor_kknn.R#95) 
      3. Error: (unknown) (@test_predict_formats.R#9) 
      
      Error: testthat unit tests failed
      Execution halted
    ```

# recipes

Version: 0.1.4

## In both

*   checking dependencies in R code ... NOTE
    ```
    Namespace in Imports field not imported from: ‘RcppRoll’
      All declared Imports should be used.
    ```

