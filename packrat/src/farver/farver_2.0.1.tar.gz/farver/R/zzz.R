.onLoad <- function(...) {
  load_colour_names()
}
