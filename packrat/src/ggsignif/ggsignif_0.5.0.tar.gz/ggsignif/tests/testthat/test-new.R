context("Additional tests")

library(ggplot2)


test_that("latest github issue", {

})
