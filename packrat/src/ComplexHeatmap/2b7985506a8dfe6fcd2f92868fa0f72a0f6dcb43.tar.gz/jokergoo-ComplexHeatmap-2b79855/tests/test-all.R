library(testthat)
suppressWarnings(suppressPackageStartupMessages(library(ComplexHeatmap)))

test_check("ComplexHeatmap")
