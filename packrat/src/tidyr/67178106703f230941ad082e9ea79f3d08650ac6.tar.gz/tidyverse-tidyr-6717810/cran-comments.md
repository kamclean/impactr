## Test environments

* OS X install: R 3.5
* win-builder: R-devel
* travis-ci: R 3.1, R 3.2, R 3.3, R 3.4, R-devel

## R CMD check results

0 errors | 0 warnings | 0 notes

## revdepcheck results

We checked 875 reverse dependencies (782 from CRAN + 93 from BioConductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 12 packages

Issues with CRAN packages are summarised below.

### Failed to check

* circumplex   (NA)
* colorednoise (NA)
* dexter       (NA)
* dscore       (NA)
* dynfrail     (NA)
* nationwider  (NA)
* nlmixr       (NA)
* phenofit     (NA)
* RxODE        (NA)
* sf           (NA)
* trialr       (NA)
* vlad         (NA)
