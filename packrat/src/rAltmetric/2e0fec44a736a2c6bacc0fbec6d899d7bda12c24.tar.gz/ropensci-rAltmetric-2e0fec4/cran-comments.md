Kurt Hornik writes: Can you pls add some description of 'Altmetric', and then

  (see <http....> for more information)

?

Response: I have updated the description to reflect what types of data the service provides and have also included a link to the data provider.